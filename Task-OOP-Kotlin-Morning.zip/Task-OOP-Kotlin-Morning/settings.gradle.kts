
rootProject.name = "Task-OOP-Kotlin-Morning"

