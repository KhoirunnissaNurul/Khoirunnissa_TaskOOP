package id.infinitelearning.KotlinSubmission.exercise1

/**
Latihan 1
Lengkapi fungsi myProfile di bawah ini dengan membuat variabel dengan ketentuan dibawah ini:
- Variable bertipe data string yang menyimpan nilai nama depan Anda.
- Variable bertipe data string yang menyimpan nilai nama belakang Anda.
- Variable bertipe data number yang menyimpan nilai umur Anda.
- Variable bertipe data boolean yang menyimpan nilai status Anda (single atau tidak)
Dan Cetak setiap variabel ke layar saat variable myProfile di panggil
 */
fun myProfile(): String {
    val firstName: String = "Khoirunnissa"
    val lastName: String = "Nurul"
    val age: Int = 22
    val boolean = "single"

    return ("Nama: $firstName $lastName\nUmur: $age tahun\nStatus: $(ifSingle) Single ")

}


/**
 *  Latihan 2
 *  Lengkapi fungsi di bawah ini agar dapat mencetak nilai dari parameter-parameter yang ada dengan fungsi println
 */
fun groupDetail(groupId: String, groupMember: List<Any>, session: String): Any {
    println("Titanstech: $groupId")
    println("Awan,Asril,Laila,khoirunnissa,Rio: $groupMember")
    println("Morning: $session")
    return ("groupid, groupmember, session")
}

/**
 * Latihan 3
 * Buat variable yang berisi daftar anggota group kamu,
 * Kemudian akses item yang berisi nama Anda dari variable tersebut, lalu jadikan nilai kembalian untuk fungsi myTeam ini
 *
 */
fun myTeam(s: String): List<Any> {
    val groupMember = listOf("Awan","Asril","Laila","khoirunnissa","Rio")
    val myName = groupMember ;"khoirunnissa"

    return listOf(myName)
}

/**
 * Latihan 4
 * Lengkapi dan perbaiki isi fungsi totalMember() ini dengan rumus:
 *
 *      total mentor + jumlah anggota group
 *
 */
fun totalMember(): Int {
    val mentor = arrayOf<String>("Joy", "Maulana")
    val countOfGroup = arrayOf<String>("Awan", "Asril", "Laila", "Khoirunnissa", "Rio")
    val total = mentor.size + countOfGroup.size

    return (total)
}

fun main() {

   val profileInfo = myProfile()
    println(profileInfo)

   val groupId = "Titanstech"
    val groupMembers = listOf("Awan", "Asril", "Laila", "Khoirunnissa", "Rio")
    val session = "Morning"

    groupDetail(groupId, groupMembers, session)

    val totalMember = totalMember()
    println("Total Member group : $totalMember")

    /**
     *  Latihan 5
     *  Ubah nilai argumen-argumen dari fungsi groupDetail di bawah ini sesuai dengan data group kamu
     *
     */
    groupDetail("", listOf(), "")
    println("Titanstech: $groupId")
    println("Awan,Asril,Laila,Khoirunnissa,Rio: $groupMembers")
    println("Morning: $session")
}